
my.word <- function(word){
  u = any(grepl('u',word))
  a = any(grep('a',word))
  
  if(u && a){
    print('both are present')
  }else{
    print('Either of the two is absent')
  }
}

my.word('above')
my.word('unit')
my.word('Under')