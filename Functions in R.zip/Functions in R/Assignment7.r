count =0

is.prime <- function(num) {
  for(n in num){
    for(i in 2:(n-1)){
      if((n %% i) != 0){
        count <- count +1
        break
      }
    }
  }
  return(count)
}


x <- c(2,2,3,3,4,5,7,11,15,19,24,29)

result <- is.prime(x)


package.skeleton(list=c("result"),name="firstpkg")