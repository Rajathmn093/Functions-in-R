#a.Find out if there are any nulls in a dataset or in some specific number of columns

isna = FALSE
count = 0

getmissingValues = function(df){
  isna <- any(is.na(df))
  if(isna == TRUE){
    count = sum(is.na(df))
  }else{
    count=0
  }
  print(paste(' Is null present in the dataset : ',isna))
  print(sprintf('Number of Columns having Na : %d',count))
}

getmissingValues(mtcars)

#b. Write a function to read data from hdfs and dump it back to hdfs

require('hdfs')

hdfs.init ()

gethadoop <- function(){
  f = hdfs.file('myfile.txt','r')
  read <- hdfs.read(f)
  hdfs.put('myfile.txt','./')
}

gethadoop()