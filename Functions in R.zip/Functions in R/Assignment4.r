my.sum <- function(num){
  if(num < 0) {
    print("Enter a positive number")
  } else {
    sum = ((num * (num + 1)) / 2)^2;
    
    print(paste("The sum is", sum))
  } 
}

my.sum(3)