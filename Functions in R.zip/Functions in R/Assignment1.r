my.prime <- function(num){
  flag =0
  if(num == 2){
    print('prime')
  }else{
    for(i in 2:(num-1)){
      if((num %% i) == 0){
        flag =1
        break
      }
    }
    if(flag==1){
      print('Not Prime')
    }else{
      print('Prime')
    }
    
  }
}

my.prime(103)
my.prime(82)
my.prime(179)
