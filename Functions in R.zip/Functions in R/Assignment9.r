# a. Find out unique combinations of data based on a particular column or group of columns.

require('sqldf')

my.func = function(df){
  return(sqldf('select count(distinct "mpg") from mtcars group by disp'))
}

print(my.func(mtcars))