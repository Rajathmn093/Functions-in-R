my.bmi <- function(wt,ht){
  bmi <- wt/(ht^2)
  if(bmi<15){
    print('Very severely underweight')
  }else if(bmi>15 & bmi<16){
    print('Severely underweight')
  }else if(bmi >16 & bmi < 18.5){
    print('Underweight')
  }else if(bmi>18.5 & bmi < 25){
    print('Normal (healthy weight)')
  }else if(bmi > 25 & bmi <30){
    print('Overweight')
  }else if(bmi > 30 & bmi < 35){
    print('Obese Class I (Moderately obese)')    
  }else if(bmi > 35 & bmi < 40){
    print('Obese Class II (Severely obese)')
  }else if(bmi > 40){
    print('Obese Class III (Very severely obese)') 
  }
}


my.bmi(100,1.8)