#a. Load some csv data from hdfs.

my.readCsv <- function(){
  
  f = hdfs.file("data.csv","r")
}

my.readCsv()

#c. Rename column names in a dataframe

df <- mtcars

my.renameCol <- function(df){
  newcolnames <- c('a1','a2','a3','a4','a5','a6','a7','a8','a9','a10','a11')
  names(df) <- newcolnames 
  return(df)
}

print(my.renameCol(df))

#d. Drop given column from a data frame

df <- mtcars

my.drop <- function(df,dropName){
  return(subset(df,select = -c(mpg)))
}

print(my.drop(df,mpg))

#e. Illustrate the difference between NA, NULL, NaN.

my.nan = function(){
  print(c(sqrt(-1), sqrt(Inf), sin(sqrt(Inf))))
  x <- c(88,NA,12,168,13)
  print(mean(x))
}

#f. Return true if and only if all rows of given vector satisfy a certain condition.

my.condition = function(df){
  return (df[df[,'mpg'] > 10,])
}

df <- mtcars

print(my.condition(df))

#g. Compute number of unique combinations in a data frame grouped by certain columns.


my.uniquerows = function(df){
  nrow(unique(df[,c('mpg','cyl','disp','hp')])) 
}

print(my.uniquerows(df))