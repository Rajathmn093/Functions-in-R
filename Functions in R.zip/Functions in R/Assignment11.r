v<- c(1,2,3,3,5,5,6,7)

#a. Remove duplicates from a given vector and return it back.

my.unique = function(v){
  return(unique(v))
}

print(my.unique(v))

#b.Compute count of distinct

my.count = function(v){
  return(length(unique(v)))
}

print(my.count(v))

#c.Concatenate two strings.

my.concat = function(str1,str2){
  return(paste(str1,str2))
}

print(my.concat('hello','world'))

#d.Perform Column-wise/Row-wise sum using apply function.

mat <- matrix(1:25,nrow=5)

my.sum <- function(mat){
  print('Column sum : \n')
  print(apply(mat,2,sum))
  print('Row Sum : \n')
  print(apply(mat,1,sum))
}

my.sum(mat)

#e.Get list of files in an hdfs path.

library('rhdfs')

my.list <- function(){
  hdfs.ls('./')  
}

my.list()

#f.Delete a file from hdfs if it exists.

f.delete <- function(){
  hdfs.rm('myFile.txt')
}

f.delete()