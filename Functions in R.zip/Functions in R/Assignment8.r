require('data.table')
library(dplyr)

df1 = data.frame(CustomerId = c(1:6), Product = c(rep("Toaster", 3), rep("Radio", 3)))
df2 = data.frame(CustomerId = c(2, 4, 6), State = c(rep("Alabama", 2), rep("Ohio", 1)))

inner <- merge(df1, df2, by = 'CustomerId')

outer <- merge(x = df1, y = df2, by = "CustomerId", all = TRUE)

left.outer <- merge(x = df1, y = df2, by = "CustomerId", all.x = TRUE)

right.outer <- merge(x = df1, y = df2, by = "CustomerId", all.y = TRUE)


filtered <- df1[df1$CustomerId == 2,]

outer %>% group_by(CustomerId) %>%
  select(CustomerId, Product, State) %>%
  summarise(avgCId = mean(CustomerId), sumCId = sum(CustomerId))

df1$NewId = df1[df1$CustomerId+2,]

write.csv(inner,file='equijoin.csv')
write.csv(outer,file='outerjoin.csv',na = "",sep = ",")
write.table(left.outer,file='leftouterjoin.csv',na = "")
write.csv(right.outer,file='rightouterjoin.csv',na = "")
write.csv(filtered,file='filtered.csv')